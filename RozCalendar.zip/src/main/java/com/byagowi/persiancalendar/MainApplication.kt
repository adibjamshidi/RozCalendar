package com.byagowi.persiancalendar

import android.app.Application
import androidx.multidex.MultiDexApplication
import com.appizona.yehiahd.fastsave.FastSave
import com.byagowi.persiancalendar.utils.initUtils
import ir.tapsell.sdk.Tapsell

class MainApplication : MultiDexApplication() {
    override fun onCreate() {
        super.onCreate()
        ReleaseDebugDifference.mainApplication(this)
        initUtils(applicationContext)
        Tapsell.initialize(this, "rqedgsdjqjkliomrbpggjptgkabkmaoalbtlamrcrlnohmoetrtdrdccrqncdimhhbdlgc")
        FastSave.init(this)


    }
}
