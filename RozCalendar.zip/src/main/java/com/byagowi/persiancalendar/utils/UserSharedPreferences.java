package com.byagowi.persiancalendar.utils;


public class UserSharedPreferences {
String appid,bannerid,interstitalid;

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getBannerid() {
        return bannerid;
    }

    public void setBannerid(String bannerid) {
        this.bannerid = bannerid;
    }

    public String getInterstitalid() {
        return interstitalid;
    }

    public void setInterstitalid(String interstitalid) {
        this.interstitalid = interstitalid;
    }
}