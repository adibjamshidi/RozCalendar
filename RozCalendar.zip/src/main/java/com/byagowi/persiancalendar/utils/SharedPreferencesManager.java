package com.byagowi.persiancalendar.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferencesManager {
    private static final String SHARED_PREFERENCES_NAME = "user_shared_preferences";
    private SharedPreferences sharedPreferences;

    public SharedPreferencesManager(Context context) {
        sharedPreferences = context.getSharedPreferences(SHARED_PREFERENCES_NAME, context.MODE_PRIVATE);
    }

    public UserSharedPreferences get_shared_preferences() {
        UserSharedPreferences user = new UserSharedPreferences();
        user.setAppid(sharedPreferences.getString("appid", ""));
        user.setBannerid(sharedPreferences.getString("bannerid", ""));
        user.setInterstitalid(sharedPreferences.getString("interstitalid", ""));


        return user;
    }



    public void set_name(UserSharedPreferences user) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("appid", user.getAppid());
        editor.putString("bannerid", user.getBannerid());
        editor.putString("interstitalid", user.getInterstitalid());

        editor.apply();
    }
}