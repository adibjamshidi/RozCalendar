package com.byagowi.persiancalendar;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.view.View;
import android.widget.LinearLayout;


import com.appizona.yehiahd.fastsave.FastSave;
import com.jeevandeshmukh.fancybottomsheetdialoglib.FancyBottomSheetDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class AdibAds {












    public static void about(Activity ctx){

        if (!FastSave.getInstance().isKeyExists("firrrrr")) {
            new FancyBottomSheetDialog.Builder(ctx)
                    .setTitle("توجه!")
                    .setMessage("سورس این برنامه به صورت آزاد از برنامه تقویم فارسی در گیتهاب فورک شده است \n\n لینک سورس تقویم فارسی:\n https://github.com/persian-calendar/DroidPersianCalendar  \nلینک سورس تقویم فارسی رز :\n https://github.com/adibjamshidi/RozCalendar  \nتوجه: لازم است به همان شکلی سورس برنامه را به همراه برنامه دریافت کرده\u200Cاید، بسورس برنامه تغییر داده شده خود را حداقل در هر انتشار در جایی عمومی قرار دهید و پیوند آن را هم به صورت عمومی قرار دهید و ارجاع مناسب به سورس اصلی دهید")
                    .setBackgroundColor(Color.parseColor("#3F51B5")) //don't use R.color.somecolor
                    .setIcon(R.mipmap.ic_launcher, true)
                    .isCancellable(false)
                    .OnNegativeClicked(new FancyBottomSheetDialog.FancyBottomSheetDialogListener() {
                        @Override
                        public void OnClick() {

                        }
                    })
                    .setNegativeBtnText("تایید")
                    .setNegativeBtnBackground(Color.WHITE)
                    .build();
            FastSave.getInstance().saveBoolean("firrrrr",true);
        }

    }

}
