package com.tagvim.parsi;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import ir.tapsell.sdk.Tapsell;
import ir.tapsell.sdk.TapsellAdRequestListener;
import ir.tapsell.sdk.TapsellAdRequestOptions;
import ir.tapsell.sdk.TapsellShowOptions;
import ir.tapsell.sdk.bannerads.TapsellBannerType;
import ir.tapsell.sdk.bannerads.TapsellBannerView;

public class AdibTaps {

    public static void loadfull(final Context ths){



    }

    public static void loadbanner(View ths){
         LinearLayout linini = ths.findViewById(R.id.linini);
        TapsellBannerView bannerView = new TapsellBannerView(ths.getContext(), TapsellBannerType.BANNER_320x50,"5e2ca710aeaec60001fb7a96");
        linini.addView(bannerView);



    }
}
