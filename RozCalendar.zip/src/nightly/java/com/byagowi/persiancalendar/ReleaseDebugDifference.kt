package com.byagowi.persiancalendar

import android.app.Application
import android.content.Context

object ReleaseDebugDifference {
    fun mainApplication(app: Application?) {} // Nothing here
    fun startLynxListenerIfIsDebug(context: Context?) {} // Nothing here
}